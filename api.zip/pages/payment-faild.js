import React from 'react';
import PaymentFaild from "../src/components/PaymentFaild";
import Layout from "../src/components/Partials/Layout";

function PaymentFaildPage() {
    return (
        <Layout>
            <PaymentFaild/>
        </Layout>

    );
}

export default PaymentFaildPage;